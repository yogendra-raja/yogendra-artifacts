from datetime import datetime, timezone
import re


def sap_date_to_iso_8601(sap_date: str) -> str:
    """
    Convert a string SAP API input format to ISO 8601 ie., "/Date(<DATE-IN-MILISECONDS>)/" -> "YYYY-
    MM-DD" .

    :param sap_date: the date as a string in SAP API input format (ie., `/Date(1661990400000)/`).
    :return: The date as a string in ISO 8601 format (ie., YYYY-MM-DD), or the string itself if the pattern is not found.
    """
    match = re.search(r"/Date\((\d+)\)/", sap_date)
    if match:
        timestamp_ms = int(match.group(1))
        dt = datetime.fromtimestamp(timestamp_ms / 1000, tz=timezone.utc)
        return dt.strftime("%Y-%m-%d")
    return sap_date


def iso_8601_to_sap_date(date: str, *, tzinfo: timezone = timezone.utc) -> str:
    """
    Convert a string in ISO 8601 format to the SAP API input format ie., "YYYY-MM-DD" ->
    "/Date(<DATE-IN-MILISECONDS>)/".

    :param date: the date as a string in ISO 8601 format (ie., YYYY-MM-DD).
    :param tzinfo: the timezone info, utc by default.
    :return: the date as a string in SAP API input format.
    """
    date_as_datetime = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=tzinfo)
    date_as_milliseconds = int(date_as_datetime.timestamp() * 1000)
    return f"/Date({date_as_milliseconds})/"


def iso_8601_datetime_convert_to_date(iso_datetime: str) -> str:
    """
    Converts an ISO 8601 datetime string to a ISO 8601 date in 'YYYY-MM-DD' format. Used for
    reformatting dates given from Seismic APIs.

    :param iso_datetime: The ISO 8601 datetime string (e.g., "2019-06-18T16:29:37.960Z").
    :return: The date in 'YYYY-MM-DD' format.
    """
    return datetime.fromisoformat(iso_datetime.rstrip("Z")).date().isoformat()
