from enum import StrEnum


class Systems(StrEnum):
    """
    Enum specifying the system (eg.

    Workday, ServiceNow, DnB, etc).
    """

    ARIBA = "ARIBA"
    BOX = "BOX"
    COUPA = "COUPA"
    DNB = "DNB"
    MICROSOFT = "MICROSOFT"
    ORACLE_HCM = "ORACLE_HCM"
    SALESFORCE = "SALESFORCE"
    SAP_SUCCESSFACTORS = "SAP_SUCCESSFACTORS"
    SEISMIC = "SEISMIC"
    SERVICENOW = "SERVICENOW"
    WORKDAY = "WORKDAY"
    GOOGLE = "GOOGLE"
    JIRA = "JIRA"
    SLACK = "SLACK"
    SAP_S4_HANA = "SAP_S4_HANA"
    MILVUS = "MILVUS"
    WATSONX_AI = "WATSONX_AI"
    ADOBEWORKFRONT = "ADOBEWORKFRONT"
